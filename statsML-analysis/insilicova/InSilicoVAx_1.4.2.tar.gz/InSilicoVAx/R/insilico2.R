#' Modified InSilicoVA methods for arbitrary data
#'
#' @export insilico2

insilico2 <- function(data, train, cause,
    thre = 0.95, type = "quantile",
    isNumeric = FALSE,
    updateCondProb = TRUE,
    # keepProbbase.level = TRUE,
    #  CondProb = NULL,
    #  CondProbNum = NULL,
    #  datacheck = TRUE,
    #  datacheck.missing = TRUE,
    #  warning.write = FALSE,
    #  external.sep = TRUE,
    Nsim = 4000, thin = 10, burnin = 2000, auto.length = TRUE,
    conv.csmf = 0.02, jump.scale = 0.1,
    # levels.prior = NULL,
    levels.strength = NULL,
    trunc.min = 0.0001, trunc.max = 0.9999,
    #  subpop = NULL,
    java_option = "-Xmx1g",
    seed = 1
    #  phy.code = NULL, phy.cat = NULL, phy.unknown = NULL,
    #  phy.external = NULL, phy.debias = NULL, exclude.impossible.cause = TRUE,
    #  impossible.combination = NULL,
    #  indiv.CI = NULL, CondProbTable=NULL, known_labels = NULL
    ){

    prob.learn <- extract.prob(train = train, gs = cause, gstable = NULL,
      thre = thre, type = type, isNumeric = isNumeric)

    # remove unused symptoms
	  col.exist <- c(colnames(data)[1], cause, colnames(prob.learn$symps.train))
	  remove <- which(colnames(data) %in% col.exist == FALSE)

    if(length(remove) > 0){
		  warning(paste(length(remove), "symptoms deleted from testing data to match training data:",
			  paste(colnames(data)[remove], collapse = ", ")),
			  immediate. = TRUE)
		  data <- data[, -remove]
	  }

    if(updateCondProb){
			probbase.touse <- prob.learn$cond.prob.alpha
			CondProbNum <- NULL
		}else{
			probbase.touse <- prob.learn$cond.prob
			CondProbNum <- prob.learn$cond.prob
		}
		table.alpha <- prob.learn$table.alpha
		table.num <- prob.learn$table.num

    # default levels.strength for two different P(S|C) extraction
	  if(is.null(levels.strength)){
	    if(type == "empirical"){
	      levels.strength <- 1 # doesn't matter anyway
	    }else if(type == "fixed"){
	      levels.strength <- 1
	    }else if(type == "quantile"){
	      levels.strength <- 0.01
	    }
	  }

    fit <- insilico.fit(data = data,
						isNumeric = isNumeric,
						updateCondProb = updateCondProb,
						keepProbbase.level = TRUE,
						CondProb = NULL,
						CondProbNum = NULL,
						datacheck = FALSE,
						datacheck.missing = FALSE,
						warning.write = FALSE,
						external.sep = FALSE,
						Nsim = Nsim,
						thin = thin,
						burnin = burnin,
						auto.length = auto.length,
						conv.csmf = conv.csmf,
						jump.scale = jump.scale,
						levels.prior = NULL,
						levels.strength = levels.strength,
						trunc.min = trunc.min,
						trunc.max = trunc.max,
						subpop = NULL,
						java_option = java_option,
						seed = seed,
						phy.code = NULL,
						phy.cat = NULL,
						phy.unknown = NULL,
						phy.external = NULL,
						phy.debias = NULL,
						exclude.impossible.cause = FALSE,
						indiv.CI = NULL,
						impossible.combination = NULL,
						customization.dev = TRUE,
						Probbase_by_symp.dev = FALSE,
						probbase.dev = probbase.touse,
						table.dev = table.alpha,
						table.num.dev = table.num,
						gstable.dev = colnames(probbase.touse),
						nlevel.dev = 15,
						known_labels = NULL
					  )

	return(fit)

}